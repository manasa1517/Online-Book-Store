export default {
  products: [
    {
      _id: '1',
      name: 'Cat',
      category: 'exam',
      image: '/images/cat.jpeg',
      price: 860,
      brand: 'exam',
      rating: 4.5,
      numReviews: 10
    },
    {
      _id: '2',
      name: 'General Science',
      category: 'General Knowledge',
      image: '/images/generalscience.jpeg',
      price: 50,
      brand: ' General Knowledges',
      rating: 4.2,
      numReviews: 5
    },
    {
      _id: '3',
      name: 'India Struggle',
      category: 'Polity',
      image: '/images/indiasstruggle.jpeg',
      price: 70,
      brand: ' Polity',
      rating: 4.5,
      numReviews: 8
    }, {
      _id: '4',
      name: 'stories',
      category: 'stories',
      image: '/images/d1.jpg',
      price: 70,
      brand: ' stories',
      rating: 4.5,
      numReviews: 8
    },
  ]
}